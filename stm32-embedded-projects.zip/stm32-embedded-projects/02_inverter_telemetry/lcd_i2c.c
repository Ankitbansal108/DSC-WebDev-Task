#include "lcd_i2c.h"

/* PCF8574 bit map used by the common backpack: P0=RS P1=RW P2=EN P3=backlight P4..P7=D4..D7 */
#define LCD_RS 0x01u
#define LCD_EN 0x04u
#define LCD_BL 0x08u

static I2C_HandleTypeDef *bus;
static uint16_t addr8;

static void pcf_write(uint8_t v)
{
    HAL_I2C_Master_Transmit(bus, addr8, &v, 1, 20);
}

static void write_nibble(uint8_t nib, uint8_t rs)
{
    uint8_t d = (uint8_t)((nib << 4) | LCD_BL | (rs ? LCD_RS : 0));
    pcf_write(d | LCD_EN);
    pcf_write(d & (uint8_t)~LCD_EN);
}

static void write_byte(uint8_t b, uint8_t rs)
{
    write_nibble(b >> 4, rs);
    write_nibble(b & 0x0F, rs);
}

void lcd_init(I2C_HandleTypeDef *hi2c, uint8_t addr7)
{
    bus = hi2c;
    addr8 = (uint16_t)(addr7 << 1);
    HAL_Delay(50);
    write_nibble(0x03, 0); HAL_Delay(5);   /* reset sequence per HD44780 datasheet */
    write_nibble(0x03, 0); HAL_Delay(1);
    write_nibble(0x03, 0); HAL_Delay(1);
    write_nibble(0x02, 0);                 /* switch to 4-bit mode */
    write_byte(0x28, 0);                   /* 4-bit, 2 lines, 5x8 font */
    write_byte(0x0C, 0);                   /* display on, cursor off */
    write_byte(0x06, 0);                   /* entry mode: increment */
    lcd_clear();
}

void lcd_clear(void)
{
    write_byte(0x01, 0);
    HAL_Delay(2);
}

void lcd_set_cursor(uint8_t row, uint8_t col)
{
    write_byte((uint8_t)(0x80 | ((row ? 0x40 : 0x00) + col)), 0);
}

void lcd_print(const char *s)
{
    while (*s) write_byte((uint8_t)*s++, 1);
}
