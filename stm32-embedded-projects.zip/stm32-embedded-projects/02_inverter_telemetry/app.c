/*
 * Project 02 - Solar inverter telemetry node (bench prototype).
 *  - Samples a "PV voltage" on ADC1 (PA0 via a resistor divider) and, optionally, a current sensor on ADC1 ch1 (PA1).
 *  - Shows the readings on a 16x2 I2C LCD.
 *  - Sends a CRC-protected frame over UART every second (decode with tools/telemetry_parser.py).
 *
 * CubeMX: hadc1 (ch0 + ch1, single conversion, polling), hi2c1 (100 kHz), huart2 (115200 8N1).
 * Bench setup: 100k/10k divider -> ratio 11:1, so 0..30 V maps to 0..2.7 V at the pin. Use a bench supply, NOT a real PV array.
 * Add common/frame.c and common/frame.h to the project.
 */
#include "main.h"
#include "app.h"
#include "lcd_i2c.h"
#include "frame.h"
#include <stdio.h>

extern ADC_HandleTypeDef  hadc1;
extern I2C_HandleTypeDef  hi2c1;
extern UART_HandleTypeDef huart2;

#define VREF_MV            3300u
#define ADC_MAX            4095u
#define DIVIDER_RATIO      11u        /* (100k + 10k) / 10k */
#define CURRENT_MV_PER_A   185u       /* ACS712-5A sensitivity; set 0 if no sensor fitted */
#define CURRENT_ZERO_MV    2500u
#define OVERVOLT_MV        24000u
#define LCD_ADDR_7BIT      0x27u
#define REPORT_PERIOD_MS   1000u

typedef struct {
    uint16_t pv_mV;
    uint16_t current_mA;
    int16_t  temp_c10;     /* tenths of a degree C; placeholder until a sensor is added */
    uint8_t  status;       /* bit0 = over-voltage fault */
} telemetry_t;

static uint32_t last_report;

static uint16_t adc_read_channel(uint32_t channel)
{
    ADC_ChannelConfTypeDef cfg = {0};
    cfg.Channel = channel;
    cfg.Rank = 1;
    cfg.SamplingTime = ADC_SAMPLETIME_55CYCLES_5;      /* rename for your family if needed */
    HAL_ADC_ConfigChannel(&hadc1, &cfg);
    HAL_ADC_Start(&hadc1);
    HAL_ADC_PollForConversion(&hadc1, 10);
    uint16_t v = (uint16_t)HAL_ADC_GetValue(&hadc1);
    HAL_ADC_Stop(&hadc1);
    return v;
}

static uint16_t adc_avg(uint32_t channel)
{
    uint32_t sum = 0;
    for (int i = 0; i < 16; i++) sum += adc_read_channel(channel);
    return (uint16_t)(sum / 16u);
}

static void sample(telemetry_t *t)
{
    uint32_t pin_mv = (uint32_t)adc_avg(ADC_CHANNEL_0) * VREF_MV / ADC_MAX;
    t->pv_mV = (uint16_t)(pin_mv * DIVIDER_RATIO);

    if (CURRENT_MV_PER_A) {
        int32_t i_mv = (int32_t)((uint32_t)adc_avg(ADC_CHANNEL_1) * VREF_MV / ADC_MAX) - (int32_t)CURRENT_ZERO_MV;
        int32_t ma = i_mv * 1000 / (int32_t)CURRENT_MV_PER_A;
        t->current_mA = (uint16_t)(ma < 0 ? 0 : ma);
    } else {
        t->current_mA = 0;
    }
    t->temp_c10 = 250;                                 /* TODO: read internal/NTC sensor */
    t->status = (t->pv_mV > OVERVOLT_MV) ? 1u : 0u;
}

static void show_lcd(const telemetry_t *t)
{
    char line[17];
    snprintf(line, sizeof line, "PV %2u.%02uV %s", t->pv_mV / 1000u, (t->pv_mV % 1000u) / 10u,
             (t->status & 1u) ? "FAULT" : "OK   ");
    lcd_set_cursor(0, 0); lcd_print(line);
    snprintf(line, sizeof line, "I  %u.%03uA     ", t->current_mA / 1000u, t->current_mA % 1000u);
    lcd_set_cursor(1, 0); lcd_print(line);
}

static void send_frame(const telemetry_t *t)
{
    uint8_t p[7] = {
        (uint8_t)(t->pv_mV & 0xFF),      (uint8_t)(t->pv_mV >> 8),
        (uint8_t)(t->current_mA & 0xFF), (uint8_t)(t->current_mA >> 8),
        (uint8_t)((uint16_t)t->temp_c10 & 0xFF), (uint8_t)((uint16_t)t->temp_c10 >> 8),
        t->status
    };
    uint8_t wire[FRAME_MAX_PAYLOAD + 3];
    size_t n = frame_encode(p, sizeof p, wire);
    HAL_UART_Transmit(&huart2, wire, (uint16_t)n, 100);
}

void app_init(void)
{
    HAL_ADCEx_Calibration_Start(&hadc1);               /* F1/F3 families; remove if your HAL lacks it */
    lcd_init(&hi2c1, LCD_ADDR_7BIT);
    lcd_set_cursor(0, 0); lcd_print("Inverter monitor");
    HAL_Delay(800);
    last_report = HAL_GetTick();
}

void app_loop(void)
{
    if (HAL_GetTick() - last_report >= REPORT_PERIOD_MS) {
        last_report += REPORT_PERIOD_MS;
        telemetry_t t;
        sample(&t);
        show_lcd(&t);
        send_frame(&t);
    }
}
