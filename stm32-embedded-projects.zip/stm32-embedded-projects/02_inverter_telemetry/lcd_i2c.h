#ifndef LCD_I2C_H
#define LCD_I2C_H
#include "main.h"
/* HD44780 16x2 LCD behind a PCF8574 I2C backpack (default address 0x27). */
void lcd_init(I2C_HandleTypeDef *hi2c, uint8_t addr7);
void lcd_clear(void);
void lcd_set_cursor(uint8_t row, uint8_t col);
void lcd_print(const char *s);
#endif
