#include <stdio.h>
#include <string.h>
#include "../common/frame.h"

static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

int main(void)
{
    uint8_t payload[] = {0x10, 0x27, 0x64, 0x00, 0xFA, 0x00, 0x01};
    uint8_t wire[64];
    size_t n = frame_encode(payload, sizeof payload, wire);
    CHECK(n == sizeof payload + 3);

    /* 1. clean frame round-trips */
    frame_parser_t p; frame_parser_init(&p);
    int r = 0;
    for (size_t i = 0; i < n; i++) r = frame_parser_feed(&p, wire[i]);
    CHECK(r == 1); CHECK(p.len == sizeof payload); CHECK(memcmp(p.buf, payload, p.len) == 0);

    /* 2. corrupted byte is rejected */
    wire[4] ^= 0xFF;
    frame_parser_init(&p); r = 0;
    for (size_t i = 0; i < n; i++) r = frame_parser_feed(&p, wire[i]);
    CHECK(r == -1);
    wire[4] ^= 0xFF;

    /* 3. parser resyncs after garbage bytes */
    uint8_t noisy[80]; size_t m = 0;
    uint8_t junk[] = {0x00, 0x55, 0x13};
    memcpy(noisy, junk, 3); m = 3;
    memcpy(noisy + m, wire, n); m += n;
    frame_parser_init(&p); int got = 0;
    for (size_t i = 0; i < m; i++) if (frame_parser_feed(&p, noisy[i]) == 1) got++;
    CHECK(got == 1);

    /* 4. oversize payload refused */
    uint8_t big[FRAME_MAX_PAYLOAD + 1] = {0};
    CHECK(frame_encode(big, FRAME_MAX_PAYLOAD + 1, wire) == 0);

    /* 5. known CRC-8 (poly 0x07) check value for "123456789" is 0xF4 */
    CHECK(frame_crc8((const uint8_t *)"123456789", 9) == 0xF4);

    printf(fails ? "%d test(s) failed\n" : "all tests passed\n", fails);
    return fails ? 1 : 0;
}
