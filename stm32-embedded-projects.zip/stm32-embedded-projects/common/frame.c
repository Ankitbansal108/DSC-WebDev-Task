#include "frame.h"

enum { ST_SOF = 0, ST_LEN, ST_PAYLOAD, ST_CRC };

uint8_t frame_crc8(const uint8_t *data, size_t n)
{
    uint8_t crc = 0x00;
    for (size_t i = 0; i < n; i++) {
        crc ^= data[i];
        for (int b = 0; b < 8; b++)
            crc = (crc & 0x80) ? (uint8_t)((crc << 1) ^ 0x07) : (uint8_t)(crc << 1);
    }
    return crc;
}

size_t frame_encode(const uint8_t *payload, uint8_t len, uint8_t *out)
{
    if (len > FRAME_MAX_PAYLOAD) return 0;
    out[0] = FRAME_SOF;
    out[1] = len;
    for (uint8_t i = 0; i < len; i++) out[2 + i] = payload[i];
    out[2 + len] = frame_crc8(&out[1], (size_t)len + 1u);
    return (size_t)len + 3u;
}

void frame_parser_init(frame_parser_t *p)
{
    p->state = ST_SOF;
    p->len = 0;
    p->idx = 0;
}

int frame_parser_feed(frame_parser_t *p, uint8_t byte)
{
    switch (p->state) {
    case ST_SOF:
        if (byte == FRAME_SOF) p->state = ST_LEN;
        break;
    case ST_LEN:
        if (byte > FRAME_MAX_PAYLOAD) { p->state = ST_SOF; break; }
        p->len = byte;
        p->idx = 0;
        p->state = (byte == 0) ? ST_CRC : ST_PAYLOAD;
        break;
    case ST_PAYLOAD:
        p->buf[p->idx++] = byte;
        if (p->idx >= p->len) p->state = ST_CRC;
        break;
    case ST_CRC: {
        uint8_t tmp[FRAME_MAX_PAYLOAD + 1];
        tmp[0] = p->len;
        for (uint8_t i = 0; i < p->len; i++) tmp[1 + i] = p->buf[i];
        uint8_t ok = (frame_crc8(tmp, (size_t)p->len + 1u) == byte);
        p->state = ST_SOF;
        return ok ? 1 : -1;
    }
    }
    return 0;
}
