/* Simple framed serial protocol: [0xAA][len][payload...][crc8(len+payload)] */
#ifndef FRAME_H
#define FRAME_H
#include <stdint.h>
#include <stddef.h>

#define FRAME_SOF          0xAAu
#define FRAME_MAX_PAYLOAD  32u

typedef struct {
    uint8_t state;
    uint8_t len;
    uint8_t idx;
    uint8_t buf[FRAME_MAX_PAYLOAD];
} frame_parser_t;

uint8_t frame_crc8(const uint8_t *data, size_t n);                       /* poly 0x07 */
size_t  frame_encode(const uint8_t *payload, uint8_t len, uint8_t *out); /* returns bytes written, 0 on error */
void    frame_parser_init(frame_parser_t *p);
/* returns 1 = valid frame (payload in p->buf, length p->len), -1 = CRC error, 0 = need more bytes */
int     frame_parser_feed(frame_parser_t *p, uint8_t byte);

#endif
