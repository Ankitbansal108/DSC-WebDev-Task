#!/usr/bin/env python3
"""Host-side decoder for the inverter telemetry frames sent by project 02.

Frame:   0xAA | len | payload | crc8(len + payload)      (CRC-8, poly 0x07)
Payload: pv_mV u16 | current_mA u16 | temp_c10 i16 | status u8   (little-endian, 7 bytes)

Usage:
  python3 telemetry_parser.py --port COM5            # live from the board (needs pyserial)
  python3 telemetry_parser.py --port /dev/ttyACM0
  python3 telemetry_parser.py --demo                 # self-test, no hardware
"""
import argparse
import struct
import sys

SOF = 0xAA
MAX_PAYLOAD = 32


def crc8(data: bytes) -> int:
    crc = 0
    for b in data:
        crc ^= b
        for _ in range(8):
            crc = ((crc << 1) ^ 0x07) & 0xFF if crc & 0x80 else (crc << 1) & 0xFF
    return crc


def encode(payload: bytes) -> bytes:
    body = bytes([len(payload)]) + payload
    return bytes([SOF]) + body + bytes([crc8(body)])


class Parser:
    def __init__(self):
        self.reset()

    def reset(self):
        self.state, self.length, self.buf = "sof", 0, bytearray()

    def feed(self, b: int):
        """Returns payload bytes for a valid frame, 'crc' on CRC error, else None."""
        if self.state == "sof":
            if b == SOF:
                self.state = "len"
        elif self.state == "len":
            if b > MAX_PAYLOAD:
                self.reset()
            else:
                self.length, self.buf = b, bytearray()
                self.state = "crc" if b == 0 else "payload"
        elif self.state == "payload":
            self.buf.append(b)
            if len(self.buf) >= self.length:
                self.state = "crc"
        elif self.state == "crc":
            ok = crc8(bytes([self.length]) + bytes(self.buf)) == b
            payload = bytes(self.buf)
            self.reset()
            return payload if ok else "crc"
        return None


def decode(payload: bytes) -> dict:
    pv_mv, cur_ma, temp10, status = struct.unpack("<HHhB", payload)
    return {"pv_V": pv_mv / 1000, "current_A": cur_ma / 1000, "temp_C": temp10 / 10, "status": status}


def show(d: dict):
    flags = "FAULT" if d["status"] & 1 else "OK"
    print(f"PV {d['pv_V']:6.2f} V | I {d['current_A']:5.3f} A | P {d['pv_V'] * d['current_A']:7.2f} W | "
          f"T {d['temp_C']:5.1f} C | {flags}")


def demo() -> int:
    samples = [(18250, 420, 312, 0), (18010, 455, 318, 0), (3000, 0, 405, 1)]
    stream = b"\x00\x13" + b"".join(encode(struct.pack("<HHhB", *s)) for s in samples)
    bad = bytearray(encode(struct.pack("<HHhB", 1, 2, 3, 0)))
    bad[3] ^= 0xFF                      # corrupt one byte
    stream += bytes(bad)
    p, good, crc_err = Parser(), [], 0
    for b in stream:
        r = p.feed(b)
        if r == "crc":
            crc_err += 1
        elif r is not None:
            good.append(decode(r))
    for d in good:
        show(d)
    assert len(good) == 3 and crc_err == 1, (len(good), crc_err)
    assert abs(good[0]["pv_V"] - 18.25) < 1e-9 and good[2]["status"] == 1
    print("demo OK: 3 frames decoded, 1 corrupted frame rejected")
    return 0


def live(port: str, baud: int) -> int:
    import serial  # pip install pyserial
    p = Parser()
    with serial.Serial(port, baud, timeout=1) as ser:
        while True:
            for b in ser.read(64):
                r = p.feed(b)
                if r == "crc":
                    print("CRC error")
                elif r is not None:
                    show(decode(r))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--port")
    ap.add_argument("--baud", type=int, default=115200)
    ap.add_argument("--demo", action="store_true")
    a = ap.parse_args()
    if a.demo or not a.port:
        sys.exit(demo())
    sys.exit(live(a.port, a.baud))
