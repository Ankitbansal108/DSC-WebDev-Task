# STM32 Embedded Projects

Two small STM32 (HAL, Embedded C) projects covering UART, I2C, SPI, ADC, an I2C LCD and a CRC-checked serial protocol, with host-side tests.

| Project | What it does |
|---|---|
| `01_protocol_bringup` | UART logging, I2C bus scan, MPU6050 accelerometer read over I2C, SPI loopback self-test |
| `02_inverter_telemetry` | Samples a DC voltage (and optional current sensor) on ADC, shows it on a 16x2 I2C LCD, sends CRC-8 framed telemetry over UART every second |
| `common/` | `frame.c/.h` - framing + CRC-8 parser (hardware independent, unit tested) |
| `tools/telemetry_parser.py` | PC-side decoder for the telemetry frames (live serial or `--demo`) |

## Hardware
- Any STM32 Nucleo board (developed against NUCLEO-F103RB style pinout; adjust ADC sampling-time macro for other families)
- MPU6050 breakout, 16x2 HD44780 LCD with PCF8574 I2C backpack (address 0x27)
- Resistor divider 100k/10k on PA0 for the voltage input. Use a bench supply (0-24 V), not a real solar array.

## Build (STM32CubeIDE)
1. Create a project for your board. In CubeMX enable: `USART2` (115200 8N1), `I2C1` (100 kHz), `SPI1` (master, full duplex, 8-bit) for project 01, `ADC1` (channels 0 and 1) for project 02.
2. Copy the project's `app.c/app.h` (and `lcd_i2c.*`, `common/frame.*` for project 02) into `Core/Src` and `Core/Inc`.
3. In `main.c`: call `app_init();` before the main loop and `app_loop();` inside `while (1)`.
4. Build, flash, open the ST-Link virtual COM port at 115200 baud.

Project 02 frames are binary; decode them with `python3 tools/telemetry_parser.py --port <COM port>`.

## Tests (no hardware needed)
```
make test
```
Runs C unit tests for the framing/CRC code (round-trip, corrupted byte, resync after noise, oversize payload, CRC-8 check value) and a Python decoder self-test.

## Status
- Host tests pass.
- Firmware sources compile-checked for syntax against a HAL stub. Flash and verify on your own board, then add photos or a serial log screenshot to this repo.

## Frame format
`0xAA | len | payload | crc8(len + payload)`, CRC-8 poly 0x07.
Telemetry payload (little-endian, 7 bytes): `pv_mV u16 | current_mA u16 | temp_c10 i16 | status u8`.
