/*
 * Project 01 - Peripheral bring-up: UART logging, I2C bus scan + MPU6050, SPI loopback.
 * Target: any STM32 Nucleo with HAL (written for NUCLEO-F103RB / F411RE style pinouts).
 * CubeMX handles: huart2 (115200 8N1, ST-Link VCP), hi2c1 (100 kHz), hspi1 (master, full-duplex, 8-bit).
 * Wiring: MPU6050 on I2C1 (SCL/SDA + 3V3 + GND). SPI test: jumper MOSI -> MISO.
 */
#include "main.h"
#include "app.h"
#include <stdio.h>
#include <string.h>

extern UART_HandleTypeDef huart2;
extern I2C_HandleTypeDef  hi2c1;
extern SPI_HandleTypeDef  hspi1;

#define MPU6050_ADDR      (0x68u << 1)
#define MPU_REG_WHO_AM_I  0x75u
#define MPU_REG_PWR_MGMT  0x6Bu
#define MPU_REG_ACCEL_OUT 0x3Bu

static uint8_t mpu_ok;

static void log_printf(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
#include <stdarg.h>
static void log_printf(const char *fmt, ...)
{
    char line[96];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(line, sizeof line, fmt, ap);
    va_end(ap);
    if (n > 0) HAL_UART_Transmit(&huart2, (uint8_t *)line, (uint16_t)n, 100);
}

static void i2c_scan(void)
{
    log_printf("I2C scan:\r\n");
    uint8_t found = 0;
    for (uint8_t a = 0x08; a < 0x78; a++) {
        if (HAL_I2C_IsDeviceReady(&hi2c1, (uint16_t)(a << 1), 2, 10) == HAL_OK) {
            log_printf("  device at 0x%02X\r\n", a);
            found++;
        }
    }
    if (!found) log_printf("  none found - check pull-ups and wiring\r\n");
}

static void mpu_init(void)
{
    uint8_t id = 0, wake = 0;
    if (HAL_I2C_Mem_Read(&hi2c1, MPU6050_ADDR, MPU_REG_WHO_AM_I, 1, &id, 1, 50) != HAL_OK) {
        log_printf("MPU6050: no response\r\n");
        return;
    }
    log_printf("MPU6050 WHO_AM_I = 0x%02X (expect 0x68)\r\n", id);
    if (id != 0x68) return;
    HAL_I2C_Mem_Write(&hi2c1, MPU6050_ADDR, MPU_REG_PWR_MGMT, 1, &wake, 1, 50); /* leave sleep mode */
    mpu_ok = 1;
}

static void mpu_report(void)
{
    uint8_t raw[6];
    if (HAL_I2C_Mem_Read(&hi2c1, MPU6050_ADDR, MPU_REG_ACCEL_OUT, 1, raw, 6, 50) != HAL_OK) {
        log_printf("MPU6050 read error\r\n");
        return;
    }
    int16_t ax = (int16_t)((raw[0] << 8) | raw[1]);
    int16_t ay = (int16_t)((raw[2] << 8) | raw[3]);
    int16_t az = (int16_t)((raw[4] << 8) | raw[5]);
    /* +-2 g range -> 16384 LSB/g; print in milli-g to avoid float printf */
    log_printf("accel mg: x=%d y=%d z=%d\r\n",
               (int)(ax * 1000L / 16384), (int)(ay * 1000L / 16384), (int)(az * 1000L / 16384));
}

static void spi_loopback_test(void)
{
    uint8_t tx[8] = {0xA5, 0x5A, 0x00, 0xFF, 0x12, 0x34, 0x56, 0x78};
    uint8_t rx[8] = {0};
    HAL_StatusTypeDef st = HAL_SPI_TransmitReceive(&hspi1, tx, rx, sizeof tx, 100);
    log_printf("SPI loopback: %s\r\n",
               (st == HAL_OK && memcmp(tx, rx, sizeof tx) == 0) ? "PASS" : "FAIL (jumper MOSI->MISO?)");
}

void app_init(void)
{
    log_printf("\r\n== Protocol bring-up ==\r\n");
    i2c_scan();
    mpu_init();
    spi_loopback_test();
}

void app_loop(void)
{
    if (mpu_ok) mpu_report();
    HAL_Delay(500);
}
